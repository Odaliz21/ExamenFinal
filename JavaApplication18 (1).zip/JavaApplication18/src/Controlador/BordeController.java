
package Controlador;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;

public class BordeController implements Initializable {


    @FXML
    private Button btnEntrarRegistro;
    
    @FXML
    private StackPane spContenedor;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }  
    
   
   @FXML
   void EntrarRegistro(ActionEvent event) {
       try {
            Parent spResgistro = FXMLLoader.load(getClass().getResource("/visual/RegistroPago.fxml"));
           spContenedor.getChildren().removeAll();
           spContenedor.getChildren().setAll(spResgistro);
        } catch (IOException ex) {
           Logger.getLogger(BordeController.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
}
