
package ClasePrincipal;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

public class Jasper {

    public static void main(String[] str) {
        try{
            JasperReport jasperReport = null;
            JasperPrint jasperPrint = null;
            JasperDesign jasperDesign = null;
            Map paramaters = new HashMap();
            jasperDesign = JRXmlLoader.load("C:\\Reportes\\ListaRegistro.jrxml");
            jasperReport = JasperCompileManager.compileReport(jasperDesign);
            jasperPrint = JasperFillManager.fillReport(jasperReport,paramaters,
                         new JRBeanCollectionDataSource(Registro.generaRegistroMensualidad()));
            JasperExportManager.exportReportToPdfFile(jasperPrint,"target/ListaRegistro.pdf");
            JasperViewer.viewReport(jasperPrint);
        } catch (Exception ex) {
            System.out.println("EXCEPTION: " + ex);
        }
    }

    private static class Registro {

        private static Collection<?> generaRegistroMensualidad() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public Registro() {
        }
    }
}
