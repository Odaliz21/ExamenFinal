package Controlador;

import ClasePrincipal.FXMain;
import java.io.File;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.util.StringConverter;
import java.time.format.DateTimeFormatter;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import java.io.IOException;
import java.io.FileWriter;
import java.util.HashMap;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

public class PagoController implements Initializable {

 

    @FXML
    private Button btnGuardar;
    
    @FXML
    private Button btnEliminar;
    
    @FXML
    private Button btnImprimir;
    
    @FXML
    private ComboBox<String> cbxGrado;
   
    
    @FXML
    private ComboBox<String> cbxGenero;
    
    @FXML
    private ComboBox<String> cbxMarzo;
    
    @FXML
    private ComboBox<String> cbxAbril;
    
    @FXML
    private ComboBox<String> cbxMayo;
    
    @FXML
    private ComboBox<String> cbxJunio;
    
    @FXML
    private ComboBox<String> cbxJulio;
    
    @FXML
    private ComboBox<String> cbxAgosto;
    
    @FXML
    private ComboBox<String> cbxSeptiembre;
    
    @FXML
    private ComboBox<String> cbxOctubre;
    
    @FXML
    private ComboBox<String> cbxNoviembre;
    
    @FXML
    private ComboBox<String> cbxDiciembre;

    @FXML
    private TextField txtMatricula;

    @FXML
    private TextField txtNombre;
    
    @FXML
    private TextField txtApellidos;

    @FXML
    private TextField txtPagoTotal;
    
   
    

    @FXML
    void Guardar(ActionEvent event) {
 
        String Nombre = txtNombre.getText();
        String Apellidos = txtApellidos.getText();
        String PagoTotal = txtPagoTotal.getText();
        String CostoMatricula = txtMatricula.getText();
        String Genero = cbxGenero.getValue();
        String Grado = cbxGrado.getValue();
          String Marzo =cbxMarzo.getValue();
          String Abril=cbxAbril.getValue();
          String Mayo =cbxMayo .getValue();
         String Junio= cbxJunio.getValue();
          String Julio=cbxJulio.getValue();
          String Agosto =cbxAgosto.getValue();
          String Septiembre =cbxSeptiembre.getValue();
          String Octubre=cbxOctubre.getValue();
          String Noviembre =cbxNoviembre.getValue();
          String Diciembre =cbxDiciembre.getValue();
                            
    try {
        FileWriter fileWriter = new FileWriter("Registro.txt", true); // Abre el archivo en modo de escritura (append=true para agregar al final del archivo)
        fileWriter.write("Nombre: " + Nombre+ "\n");
        fileWriter.write("Apellidos: " + Apellidos+ "\n");
        fileWriter.write("PagoTotal : " + PagoTotal + "\n");
        fileWriter.write("CostoMatricula : " + CostoMatricula  + "\n");
        fileWriter.write("Genero: " + Genero  + "\n");
         fileWriter.write("Grado : " + Grado  + "\n");
        fileWriter.write("Marzo : " + Marzo  + "\n");
         fileWriter.write("Abril : " + Abril  + "\n");
          fileWriter.write("Mayo  : " + Mayo   + "\n");
           fileWriter.write("Junio : " + Junio  + "\n");
            fileWriter.write("Julio : " + Julio  + "\n"); 
            fileWriter.write("Agosto : " + Agosto  + "\n");
             fileWriter.write("Septiembre : " + Septiembre  + "\n");
              fileWriter.write("Octubre : " + Octubre  + "\n");
               fileWriter.write(" Noviembre: " +  Noviembre  + "\n");
                fileWriter.write("Diciembre : " + Diciembre  + "\n");
         
        fileWriter.close(); // Cierra el archivo

        System.out.println("Datos guardados correctamente en el archivo.");
        } 
    catch (IOException e) {
        System.out.println("Error al guardar los datos en el archivo: " + e.getMessage());
        }
    
    }
    
    
    @FXML
    void Imprimir(ActionEvent event){
        try {
            // Compilar el archivo JRXML para obtener el archivo Jasper
            String rutaJRXML = "C:\\Reportes\\ListaRegistro.jrxml";
            JasperCompileManager.compileReportToFile(rutaJRXML);
            
            // Rellenar el informe con datos
            JasperPrint jasperPrint = JasperFillManager.fillReport(rutaJRXML, new HashMap<>(), new JREmptyDataSource());
            
            // Exportar el informe a un archivo PDF
            String rutaSalidaPDF = "C:\\Reportes\\salida.pdf";
            JasperExportManager.exportReportToPdfFile(jasperPrint, rutaSalidaPDF);
            
            // Abrir el archivo PDF con el programa predeterminado
            File archivoPDF = new File(rutaSalidaPDF);
            if (archivoPDF.exists()) {
                ProcessBuilder processBuilder = new ProcessBuilder("cmd.exe", "/C", archivoPDF.getAbsolutePath());
                processBuilder.start();
                } else {
                System.out.println("El archivo PDF no existe en la ruta especificada.");
                }
                    }         
                        catch (Exception e) 
                        {
                         System.out.println("Error al generar el informe en PDF: " + e.getMessage());
}
}


 
    
    @FXML
    void Eliminar(ActionEvent event){
    }
    
   @FXML
    
    private String[] gradito2 = {null,"1°","2°","3°","4°","5°","6°"};
    private String[] Marzo = {null,"Si","No"};
    private String[] Abril = {null,"Si","No"};
    private String[] Mayo =  {null,"Si","No"};
    private String[] Junio = {null,"Si","No"};
    private String[] Julio = {null,"Si","No"};
    private String[] Agosto =  {null,"Si","No"};
    private String[] Septiembre = {null,"Si","No"};
    private String[] Octubre  =  {null,"Si","No"};
    private String[] Noviembre =  {null,"Si","No"};   
    private String[] Diciembre =  {null,"Si","No"};
    private String[] gen = {null,"Femenino","Masculino"};
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        

        cbxGrado.getItems().addAll(gradito2);
        cbxGenero.getItems().addAll(gen);
        cbxMarzo.getItems().addAll(Marzo);
        cbxAbril.getItems().addAll(Abril);
        cbxMayo .getItems().addAll(Mayo);
        cbxJunio.getItems().addAll(Junio);
        cbxJulio.getItems().addAll(Julio);
        cbxAgosto.getItems().addAll(Agosto);
        cbxSeptiembre.getItems().addAll(Septiembre);
        cbxOctubre.getItems().addAll(Octubre);
        cbxNoviembre.getItems().addAll(Noviembre);
        cbxDiciembre.getItems().addAll(Diciembre);
        
        
    }

   
   

}


